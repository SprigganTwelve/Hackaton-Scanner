
class Email{
    
}